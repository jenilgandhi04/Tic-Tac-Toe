package ttt.bean;

public class Player {
	private int playerSign;
	private String playerName;
	
	public int getPlayerSign() {
		return playerSign;
	}

	public void setPlayerSign(int playerSign) {
		this.playerSign = playerSign;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

}
