drop table game;
drop table users;
drop sequence hibernate_sequence;